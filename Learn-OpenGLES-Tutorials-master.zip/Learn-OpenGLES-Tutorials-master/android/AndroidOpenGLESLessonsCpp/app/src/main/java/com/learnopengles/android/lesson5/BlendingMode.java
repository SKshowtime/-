package com.learnopengles.android.lesson5;

interface BlendingMode {
    void switchMode();
}
