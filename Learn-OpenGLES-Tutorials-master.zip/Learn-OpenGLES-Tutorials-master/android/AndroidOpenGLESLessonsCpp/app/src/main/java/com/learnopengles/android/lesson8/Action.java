package com.learnopengles.android.lesson8;

interface Action {
    void setDelta(float deltaX, float deltaY);
}
